// Send button alert
document.querySelector('.btn').addEventListener('click', () => {
  alert('Message sent successfully!');
});